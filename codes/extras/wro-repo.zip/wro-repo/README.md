# WRO Future Engineers 2026 — Self-Driving Car

This repository documents our vehicle for the **WRO Future Engineers – Self-Driving Cars** challenge (2026 season). It contains the source code, hardware description and wiring information for the parts of the vehicle we have built and tested so far.

---

## Table of Contents

1. [The Challenge](#the-challenge)
2. [Vehicle Layout](#vehicle-layout)
3. [Hardware](#hardware)
4. [Power and Wiring](#power-and-wiring)
5. [Software](#software)
6. [How to Run the Code](#how-to-run-the-code)
7. [Repository Structure](#repository-structure)
8. [Team](#team)

---

## The Challenge

In the Future Engineers category, a robotic vehicle must drive **fully autonomously** on a track that changes randomly for every round. There are two challenges:

- **Open Challenge** — complete three laps on a track whose inner walls are placed randomly.
- **Obstacle Challenge** — complete three laps while obeying coloured traffic signs (pillars), then perform a parallel park in a marked parking lot. The rule for the pillars is: a **red pillar must be passed on the right**, and a **green pillar must be passed on the left**.

Because the pillar positions, driving direction and starting section are randomised after the check time, the vehicle cannot use a fixed map. It must sense the field live and react. This is the central design constraint that shapes our solution.

---

## Vehicle Layout

Our vehicle uses a **rear-wheel-drive, front-steering (car-like) layout**, as required by the rules. One DC motor drives the rear axle, and one steering servo turns the front wheels. This is not a differential-drive robot, which the rules forbid.

We chose rear-wheel drive because it keeps the front wheels free to reach a larger steering angle, which makes cornering and parking easier, and because it is mechanically simpler than four-wheel drive.

---

## Hardware

The following components are used and have been tested:

| Component | Purpose |
|---|---|
| Raspberry Pi 4 (4 GB) | Main computer — runs the vision and control code |
| Raspberry Pi Camera Module v2 (IMX219) | Detects the coloured pillars and parking markers |
| DC motor + gearbox | Drives the rear axle (movement) |
| L298N motor driver | Lets the Pi control the motor without the motor's current passing through the Pi |
| SG90 servo | Steers the front wheels |
| 12 V battery | Powers the motor through the L298N |
| Separate 5 V supply | Powers the Raspberry Pi |

---

## Power and Wiring

Power is kept separate for the logic and the motors, but **all grounds are connected together (common ground)**. This is essential: without a common ground, the control signals from the Pi are not understood by the motor driver or the servo.

| From | To | Purpose |
|---|---|---|
| 12 V battery + | L298N +12V | Motor power |
| 12 V battery − | L298N GND (common ground) | Motor ground |
| L298N OUT1 / OUT2 | DC motor | Drive |
| Pi GPIO 12 | L298N ENA | Motor speed (PWM) |
| Pi GPIO 23 | L298N IN1 | Motor direction |
| Pi GPIO 24 | L298N IN2 | Motor direction |
| Pi GPIO 18 (pin 12) | Servo signal | Steering |
| L298N +5V | Servo power | Servo supply |
| Servo GND | L298N GND + Pi GND | Common ground |
| 5 V supply | Pi USB-C | Logic power |

The `ENA` jumper on the L298N is removed so that motor speed can be controlled with PWM.

A wiring diagram will be placed in the `schemes/` folder.

---

## Software

The software is written in **Python 3** and runs on the Raspberry Pi. It uses:

- **OpenCV** for computer vision.
- **picamera2** to capture frames from the Pi Camera.
- **gpiozero** and **pigpio** to control the DC motor and the steering servo.

The colour detection is designed around the **HSV colour space** rather than RGB, because HSV separates the actual colour (Hue) from the brightness (Value), which makes detection more stable when the lighting changes. A tuning tool (`src/hsv_tool.py`) is used to find the correct HSV range for each colour.

### Source files

| File | What it does |
|---|---|
| `src/camera_test.py` | Shows a live video window from the Pi Camera |
| `src/motor_test.py` | Drives the DC motor forward, reverse and stop through the L298N |
| `src/servo_test.py` | Moves the steering servo and helps find the centre and steering limits |
| `src/hsv_tool.py` | Interactive tool to find the HSV colour range for the pillars and parking markers |

---

## How to Run the Code

On the Raspberry Pi:

```bash
# Install dependencies (one time)
sudo apt update
sudo apt install -y python3-opencv python3-picamera2 pigpio python3-pigpio
sudo systemctl enable pigpiod
sudo systemctl start pigpiod

# Test the camera
python3 src/camera_test.py

# Test the motor (keep the wheels off the ground)
python3 src/motor_test.py

# Test the steering servo
python3 src/servo_test.py

# HSV colour tuning tool (run on the desktop, not over SSH)
python3 src/hsv_tool.py
```

---

## Repository Structure

```
.
├── README.md          This file
├── src/               Source code
├── schemes/           Wiring diagrams and schematics
├── t-photos/          Team photos
└── v-photos/          Vehicle photos
```

---

## Team

To be completed with team member names, roles, and a team photo in `t-photos/`.
